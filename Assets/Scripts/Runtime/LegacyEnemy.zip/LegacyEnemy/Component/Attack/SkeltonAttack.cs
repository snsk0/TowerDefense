using UnityEngine;
using Runtime.Enemy.Animation;

namespace Runtime.LegacyEnemy.Component.Attack
{
    public class SkeltonAttack : EnemyAttack
    {
        [SerializeField] private GameObject attacker;
        [SerializeField] private EnemyAnimator animator;

        public override float AttackToTarget(GameObject target, int index)
        {

            //UnityEngine.Debug.Log("attacked");
            return 1;
        }

    }
}
